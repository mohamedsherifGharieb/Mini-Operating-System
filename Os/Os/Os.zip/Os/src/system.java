import java.io.*;
import java.util.Scanner;


public class system {
    private Scanner scanner;
    private Object[] memory;
    private int processes;
    private int completedProcesses;

    private Mutex mutex;
     static Scheduler scheduler;

    public system() {
        scanner = new Scanner(System.in);
        memory = new Object[40];
        processes = 0;
        completedProcesses = 0;
        mutex=new Mutex();
        scheduler=new Scheduler();
    }
    public static void print(String s){
        System.out.println(s.length()==0 ? "no data entered ":s);
    }
    public Scheduler getScheduler(){
        return this.scheduler;
    }
    public void writeMemoryProcess (Object line, int location) {
        memory[location] = line;
    }
    public void assign(String x, String y ){
        Scanner scanner = new Scanner(System.in);
        if (y.equalsIgnoreCase("input")) {
            System.out.println("Please enter a value:");
            y = scanner.nextLine();
        }
        System.out.println(x + " = " + y);
        scanner.close();
    }
    public boolean CheckMemSlice1(){
        for (int i = 0;i<5;i++){
            if(memory[i]!=null)
                return false;
        }
        for (int i=10 ;i<25;i++){
            if(memory[i]!=null)
                return false;
        }
        return true;
    }
    public boolean CheckMemSlice2(){
            for (int i = 5;i<10;i++){
                if(memory[i]!=null)
                    return false;
            }
            for (int i=25 ;i<40;i++){
                if(memory[i]!=null)
                    return false;
            }
            return true;
        }

    public void addPCB(Object[] o , PCB P){
        boolean Slice1=true;
        boolean Slice2=true;
        for(int i=0;i<5;i++){
            if(o[i]!=null){
                Slice1=false;
                break;
            }
        }
        for(int i=5;i<10;i++){
            if(o[i]!=null){
                Slice2=false;
                break;
            }
        }
        if(Slice1==true){
            o[0]= P.getProcessID();
            o[1]= P.getProcessState();
            o[2]= P.getPC();
            o[3]= P.getCodeStart();
            o[4]= P.getCodeEnd();
        }
        else if(Slice2==true){
            o[5]= P.getProcessID();
            o[6]= P.getProcessState();
            o[7]= P.getPC();
            o[8]= P.getCodeStart();
            o[9]= P.getCodeEnd();
        }
    }
    public  String readFile(String filename) throws IOException{
        PCB Program=new PCB(processes++,ProccessState.NOTRUNNING,0,0);
        StringBuilder result = new StringBuilder();
        String path=GetFile(filename);
        Object[] pcb=new Object[5];
        pcb[0]= Program.getProcessID();
        pcb[1]= Program.getProcessState();
        pcb[2]= Program.getPC();
        pcb[3]= Program.getCodeStart();
        pcb[4]= Program.getCodeEnd();
        String[] process=new String[15];
        int i=0;
        try {
            File file=new File(path);
            BufferedReader br=new BufferedReader(new FileReader(file));
            String st;
            while((st=br.readLine())!=null){
                if(result.length()!=0)
                    result.append("\n");
                result.append(st);
                process[i++]=st;
            }
        }catch (Exception e){
            System.out.println("error at readFile");
        }
        scheduler.setReady(new Block(pcb,process));
        return result.toString();
    }
    public  void writeFile(String filename, String Data){
        if(GetFile(filename)==null){//CreateNew File to write in
         createFile(filename);
        }
        String path=GetFile(filename);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            writer.write(Data);
            System.out.println("Content written to file successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }

    }
    public  void printFromTo(int x, int y){
        while(x!=y){
            System.out.println(x++);
        }
        System.out.println(x++);
    }
    public  String GetFile(String filename){
        String Fdirectory = System.getProperty("user.dir");
        File directory = new File(Fdirectory);
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                     if (file.getName().equals(filename+".txt")) {
                       return (file.getAbsolutePath());
                    }
                }
            }
        }
        return null;
    }
    public  void createFile(String filename){
        try {
            File file = new File(filename+".txt");
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            }
        } catch (IOException e) {

            System.out.println("An error occurred.");
        }
    }
    public PCB CurrentProgram(){

        return null;
    }
    public void SemWait(String Source) throws InterruptedException {
       if(Source.equalsIgnoreCase("file")){
           mutex.semWaitAccess(CurrentProgram());

       }
       else if(Source.equalsIgnoreCase("userInput")){
           mutex.semWaitUserIn(CurrentProgram());
       }
       else{
           mutex.semWaitPrint(CurrentProgram());
       }
    }
    public  void SemSignal(String Source){
        if(Source.equalsIgnoreCase("file")){
            mutex.semSignalAccess();
        }
        else if(Source.equalsIgnoreCase("userInput")){
            mutex.semSignalUserIn();
        }
        else{
            mutex.semSignalPrint();
        }
    }

    public static void main(String[] args) {


    }

}

