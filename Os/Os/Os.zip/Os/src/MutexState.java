public enum MutexState {
    LOCKED,UNLOCKED;
}
