public enum ProccessState {
    RUNNING,NOTRUNNING,BLOCKED;
}
