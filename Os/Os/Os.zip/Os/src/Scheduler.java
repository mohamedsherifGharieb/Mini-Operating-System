import java.util.ArrayList;
import java.util.List;

public class Scheduler {
    private List<Object> Ready;
    private List<Object> block;

public Scheduler(){
    this.Ready= new ArrayList<Object>();
    this.block=new ArrayList<Object>();

}
public void Block(Object o){
    ((PCB)o).setProcessState(ProccessState.BLOCKED);
    block.add(o);
}
public void UnBlock(Object o){
    block.remove(o);
    setReady(o);
}
public void setReady(Object o){
    Ready.add(o);
    ((PCB)o).setProcessState(ProccessState.RUNNING);
}
public void swap(){

}
}
