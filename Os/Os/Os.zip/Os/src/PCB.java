public class PCB {


    private int processID;
    private ProccessState processState;
    private int PC;

    private int codeStart;
    private int codeEnd;

    public PCB(int processID, ProccessState processState,  int codeStart, int codeEnd) {
        this.processID = processID;
        this.processState = processState;
        this.PC = 1;
        this.codeStart = codeStart;
        this.codeEnd = codeEnd;
    }
    public int getProcessID() {
        return processID;
    }
    public int getPC() {
        return PC;
    }

    public void setPC(int PC) {
        this.PC = PC;
    }
    public ProccessState getProcessState() {
        return processState;
    }
    public int getCodeStart() {
        return codeStart;
    }

    public void setCodeStart(int codeStart) {
        this.codeStart = codeStart;
    }
    public int getCodeEnd() {
        return codeEnd;
    }

    public void setCodeEnd(int codeEnd) {
        this.codeEnd = codeEnd;
    }

    public void setProcessState(ProccessState P){
        this.processState=P;
    }
}
