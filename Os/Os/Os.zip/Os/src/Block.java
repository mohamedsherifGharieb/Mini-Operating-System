public class Block {
    Object[] block;

public Block(Object o1,Object o2){
    block=new Object[2];
    block[0]=o1;
    block[1]=o2;
}
}
