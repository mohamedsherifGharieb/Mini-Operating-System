import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;

public class Mutex{

    private ArrayList<PCB> Accblock;
    private List<PCB> Priblock;//printBlock
    private List<PCB> Userblock;

    private MutexState Access;
    private MutexState UserIn;
    private MutexState Print;

    public Mutex() {
        Accblock=new ArrayList<>();
        Priblock=new ArrayList<>();
        Userblock=new ArrayList<>();
        Access=MutexState.UNLOCKED;
        UserIn=MutexState.UNLOCKED;
        Print=MutexState.UNLOCKED;

    }
    public void semWaitAccess(PCB P) throws InterruptedException {
        if(Access.equals(MutexState.LOCKED)){
            Accblock.add(P);
            P.setProcessState(ProccessState.BLOCKED);
            system.scheduler.Block(P);
        }
        Access=MutexState.LOCKED;
    }
    public  void semSignalAccess(){
        Access=MutexState.UNLOCKED;
        if(!Accblock.isEmpty()){
            PCB p=Accblock.remove(0);
            p.setProcessState(ProccessState.NOTRUNNING);
            system.scheduler.setReady(p);
        }
    }
    public  void semWaitUserIn(PCB P) throws InterruptedException {
        if(UserIn.equals(MutexState.LOCKED)){
            Userblock.add(P);
            P.setProcessState(ProccessState.BLOCKED);
            system.scheduler.Block(P);
        }
        UserIn=MutexState.LOCKED;
    }
    public void semSignalUserIn(){
        UserIn=MutexState.UNLOCKED;
        if(!Userblock.isEmpty()){
            PCB p=Userblock.remove(0);
            p.setProcessState(ProccessState.NOTRUNNING);
            system.scheduler.setReady(p);
        }
    }
    public  void semWaitPrint(PCB P) throws InterruptedException {
        if(Print.equals(MutexState.LOCKED)){
            Priblock.add(P);
            P.setProcessState(ProccessState.BLOCKED);
            system.scheduler.Block(P);
        }
        Print = MutexState.LOCKED;
    }
    public void semSignalPrint(){
        Print=MutexState.UNLOCKED;
        if(!Priblock.isEmpty()){
            PCB p=Priblock.remove(0);
            p.setProcessState(ProccessState.NOTRUNNING);
            system.scheduler.setReady(p);
        }
    }
}
